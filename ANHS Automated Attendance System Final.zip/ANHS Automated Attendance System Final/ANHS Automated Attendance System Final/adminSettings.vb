﻿Imports System.Data
Imports System.Data.OleDb



Public Class adminSettings
    Dim con As New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\admin.accdb")
    Dim cm As OleDbCommand
    Dim dr As OleDbDataReader
    Private Sub adminSettings_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Try
            Dim Password = txtNewPassword.Text
            Dim ConfirmPassword = txtConfirmPassword.Text

            If Password = ConfirmPassword Then
                con.Open()
                Dim sql As String = "UPDATE ADMINS SET passw = '" & txtConfirmPassword.Text & "' WHERE usern = '" & txtUsername.Text & "'"
                cmd = New OleDb.OleDbCommand(sql, con)
                cmd.ExecuteNonQuery()
                con.Close()
                MsgBox("New Password have been saved!")
                txtUsername.Clear()
                txtNewPassword.Clear()
                txtConfirmPassword.Clear()
            Else
                MessageBox.Show("User or New Password not match!", "FAILD!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtUsername.Clear()
                txtNewPassword.Clear()
                txtConfirmPassword.Clear()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
       
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Dim Password = txtpassw.Text
            Dim ConfirmPassword = txtxConPassw.Text

            If Password = ConfirmPassword Then
                con.Open()
                Dim sql As String = " INSERT INTO ADMINS (usern, passw) values ('" & txtuser.Text & "', '" & txtxConPassw.Text & "')"
                cmd = New OleDb.OleDbCommand(sql, con)
                With cmd
                    .Parameters.AddWithValue("@usern", txtuser.Text)
                    .Parameters.AddWithValue("@passw", txtxConPassw.Text)
                    .ExecuteNonQuery()
                End With
                con.Close()
                MsgBox("New admin account added!", vbOKOnly, vbInformation)
                txtuser.Text = ""
                txtpassw.Text = ""
                txtxConPassw.Text = ""

            Else
                MessageBox.Show("Password not match!", "FAILD!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtuser.Text = ""
                txtpassw.Text = ""
                txtxConPassw.Text = ""
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try



    End Sub
End Class