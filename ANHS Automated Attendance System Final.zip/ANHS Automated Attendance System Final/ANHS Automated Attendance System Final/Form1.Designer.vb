﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.btnAbout = New System.Windows.Forms.Button()
        Me.btnLogs = New System.Windows.Forms.Button()
        Me.btmTimeOut = New System.Windows.Forms.Button()
        Me.btnAdminSettings = New System.Windows.Forms.Button()
        Me.btnTimeIn = New System.Windows.Forms.Button()
        Me.AddTeacherBtn = New System.Windows.Forms.Button()
        Me.AddStudentBtn = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.MainPanel = New System.Windows.Forms.Panel()
        Me.laberTimer = New System.Windows.Forms.Label()
        Me.MainTopPanel = New System.Windows.Forms.Panel()
        Me.btnLogOut = New System.Windows.Forms.Button()
        Me.ImagePanel = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.SideTopPanel = New System.Windows.Forms.Panel()
        Me.SideBtn = New System.Windows.Forms.Button()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.SidePanel = New System.Windows.Forms.Panel()
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.MainPanel.SuspendLayout()
        Me.ImagePanel.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SideTopPanel.SuspendLayout()
        Me.SidePanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer3
        '
        '
        'btnAbout
        '
        Me.btnAbout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAbout.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnAbout.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.btnAbout.FlatAppearance.BorderSize = 2
        Me.btnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnAbout.Font = New System.Drawing.Font("Nirmala UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAbout.Image = CType(resources.GetObject("btnAbout.Image"), System.Drawing.Image)
        Me.btnAbout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAbout.Location = New System.Drawing.Point(1, 527)
        Me.btnAbout.Name = "btnAbout"
        Me.btnAbout.Padding = New System.Windows.Forms.Padding(1)
        Me.btnAbout.Size = New System.Drawing.Size(227, 47)
        Me.btnAbout.TabIndex = 2
        Me.btnAbout.Text = "About"
        Me.btnAbout.UseVisualStyleBackColor = True
        '
        'btnLogs
        '
        Me.btnLogs.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLogs.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnLogs.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.btnLogs.FlatAppearance.BorderSize = 2
        Me.btnLogs.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnLogs.Font = New System.Drawing.Font("Nirmala UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogs.Image = CType(resources.GetObject("btnLogs.Image"), System.Drawing.Image)
        Me.btnLogs.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLogs.Location = New System.Drawing.Point(1, 433)
        Me.btnLogs.Name = "btnLogs"
        Me.btnLogs.Padding = New System.Windows.Forms.Padding(1)
        Me.btnLogs.Size = New System.Drawing.Size(227, 47)
        Me.btnLogs.TabIndex = 2
        Me.btnLogs.Text = "Time In/ Out Logs"
        Me.btnLogs.UseVisualStyleBackColor = True
        '
        'btmTimeOut
        '
        Me.btmTimeOut.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btmTimeOut.Dock = System.Windows.Forms.DockStyle.Top
        Me.btmTimeOut.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.btmTimeOut.FlatAppearance.BorderSize = 2
        Me.btmTimeOut.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btmTimeOut.Font = New System.Drawing.Font("Nirmala UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btmTimeOut.Image = CType(resources.GetObject("btmTimeOut.Image"), System.Drawing.Image)
        Me.btmTimeOut.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btmTimeOut.Location = New System.Drawing.Point(1, 386)
        Me.btmTimeOut.Name = "btmTimeOut"
        Me.btmTimeOut.Padding = New System.Windows.Forms.Padding(1)
        Me.btmTimeOut.Size = New System.Drawing.Size(227, 47)
        Me.btmTimeOut.TabIndex = 2
        Me.btmTimeOut.Text = "Time Out Scanner"
        Me.btmTimeOut.UseVisualStyleBackColor = True
        '
        'btnAdminSettings
        '
        Me.btnAdminSettings.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAdminSettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnAdminSettings.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.btnAdminSettings.FlatAppearance.BorderSize = 2
        Me.btnAdminSettings.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnAdminSettings.Font = New System.Drawing.Font("Nirmala UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdminSettings.Image = CType(resources.GetObject("btnAdminSettings.Image"), System.Drawing.Image)
        Me.btnAdminSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAdminSettings.Location = New System.Drawing.Point(1, 480)
        Me.btnAdminSettings.Name = "btnAdminSettings"
        Me.btnAdminSettings.Padding = New System.Windows.Forms.Padding(1)
        Me.btnAdminSettings.Size = New System.Drawing.Size(227, 47)
        Me.btnAdminSettings.TabIndex = 2
        Me.btnAdminSettings.Text = "Admin Settings"
        Me.btnAdminSettings.UseVisualStyleBackColor = True
        '
        'btnTimeIn
        '
        Me.btnTimeIn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnTimeIn.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnTimeIn.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.btnTimeIn.FlatAppearance.BorderSize = 2
        Me.btnTimeIn.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnTimeIn.Font = New System.Drawing.Font("Nirmala UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTimeIn.Image = CType(resources.GetObject("btnTimeIn.Image"), System.Drawing.Image)
        Me.btnTimeIn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTimeIn.Location = New System.Drawing.Point(1, 339)
        Me.btnTimeIn.Name = "btnTimeIn"
        Me.btnTimeIn.Padding = New System.Windows.Forms.Padding(1)
        Me.btnTimeIn.Size = New System.Drawing.Size(227, 47)
        Me.btnTimeIn.TabIndex = 2
        Me.btnTimeIn.Text = "Time In Scanner"
        Me.btnTimeIn.UseVisualStyleBackColor = True
        '
        'AddTeacherBtn
        '
        Me.AddTeacherBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.AddTeacherBtn.Dock = System.Windows.Forms.DockStyle.Top
        Me.AddTeacherBtn.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.AddTeacherBtn.FlatAppearance.BorderSize = 2
        Me.AddTeacherBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.AddTeacherBtn.Font = New System.Drawing.Font("Nirmala UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddTeacherBtn.Image = CType(resources.GetObject("AddTeacherBtn.Image"), System.Drawing.Image)
        Me.AddTeacherBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.AddTeacherBtn.Location = New System.Drawing.Point(1, 292)
        Me.AddTeacherBtn.Name = "AddTeacherBtn"
        Me.AddTeacherBtn.Padding = New System.Windows.Forms.Padding(1)
        Me.AddTeacherBtn.Size = New System.Drawing.Size(227, 47)
        Me.AddTeacherBtn.TabIndex = 2
        Me.AddTeacherBtn.Text = "Add New Teacher"
        Me.AddTeacherBtn.UseVisualStyleBackColor = True
        '
        'AddStudentBtn
        '
        Me.AddStudentBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.AddStudentBtn.Dock = System.Windows.Forms.DockStyle.Top
        Me.AddStudentBtn.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.AddStudentBtn.FlatAppearance.BorderSize = 2
        Me.AddStudentBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.AddStudentBtn.Font = New System.Drawing.Font("Nirmala UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddStudentBtn.Image = CType(resources.GetObject("AddStudentBtn.Image"), System.Drawing.Image)
        Me.AddStudentBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.AddStudentBtn.Location = New System.Drawing.Point(1, 245)
        Me.AddStudentBtn.Name = "AddStudentBtn"
        Me.AddStudentBtn.Size = New System.Drawing.Size(227, 47)
        Me.AddStudentBtn.TabIndex = 2
        Me.AddStudentBtn.Text = "Add New Student"
        Me.AddStudentBtn.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        '
        'MainPanel
        '
        Me.MainPanel.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.MainPanel.Controls.Add(Me.laberTimer)
        Me.MainPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MainPanel.Location = New System.Drawing.Point(229, 54)
        Me.MainPanel.Name = "MainPanel"
        Me.MainPanel.Padding = New System.Windows.Forms.Padding(1)
        Me.MainPanel.Size = New System.Drawing.Size(852, 695)
        Me.MainPanel.TabIndex = 5
        '
        'laberTimer
        '
        Me.laberTimer.AutoSize = True
        Me.laberTimer.Font = New System.Drawing.Font("Nirmala UI", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.laberTimer.Location = New System.Drawing.Point(30, 23)
        Me.laberTimer.Name = "laberTimer"
        Me.laberTimer.Size = New System.Drawing.Size(96, 37)
        Me.laberTimer.TabIndex = 0
        Me.laberTimer.Text = "Label1"
        '
        'MainTopPanel
        '
        Me.MainTopPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.MainTopPanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.MainTopPanel.Location = New System.Drawing.Point(229, 0)
        Me.MainTopPanel.Name = "MainTopPanel"
        Me.MainTopPanel.Size = New System.Drawing.Size(852, 54)
        Me.MainTopPanel.TabIndex = 4
        '
        'btnLogOut
        '
        Me.btnLogOut.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnLogOut.Font = New System.Drawing.Font("Nirmala UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.Image = CType(resources.GetObject("btnLogOut.Image"), System.Drawing.Image)
        Me.btnLogOut.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLogOut.Location = New System.Drawing.Point(1, 574)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(227, 54)
        Me.btnLogOut.TabIndex = 0
        Me.btnLogOut.Text = "Logout"
        Me.btnLogOut.UseVisualStyleBackColor = True
        '
        'ImagePanel
        '
        Me.ImagePanel.Controls.Add(Me.PictureBox1)
        Me.ImagePanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.ImagePanel.Location = New System.Drawing.Point(1, 55)
        Me.ImagePanel.Name = "ImagePanel"
        Me.ImagePanel.Size = New System.Drawing.Size(227, 190)
        Me.ImagePanel.TabIndex = 1
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(27, 22)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(168, 144)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'SideTopPanel
        '
        Me.SideTopPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(6, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.SideTopPanel.Controls.Add(Me.SideBtn)
        Me.SideTopPanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.SideTopPanel.Location = New System.Drawing.Point(1, 1)
        Me.SideTopPanel.Name = "SideTopPanel"
        Me.SideTopPanel.Size = New System.Drawing.Size(227, 54)
        Me.SideTopPanel.TabIndex = 0
        '
        'SideBtn
        '
        Me.SideBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.SideBtn.Dock = System.Windows.Forms.DockStyle.Right
        Me.SideBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.SideBtn.Image = CType(resources.GetObject("SideBtn.Image"), System.Drawing.Image)
        Me.SideBtn.Location = New System.Drawing.Point(176, 0)
        Me.SideBtn.Name = "SideBtn"
        Me.SideBtn.Size = New System.Drawing.Size(51, 54)
        Me.SideBtn.TabIndex = 0
        Me.SideBtn.UseVisualStyleBackColor = True
        '
        'Timer2
        '
        '
        'SidePanel
        '
        Me.SidePanel.BackColor = System.Drawing.SystemColors.HotTrack
        Me.SidePanel.Controls.Add(Me.btnLogOut)
        Me.SidePanel.Controls.Add(Me.btnAbout)
        Me.SidePanel.Controls.Add(Me.btnAdminSettings)
        Me.SidePanel.Controls.Add(Me.btnLogs)
        Me.SidePanel.Controls.Add(Me.btmTimeOut)
        Me.SidePanel.Controls.Add(Me.btnTimeIn)
        Me.SidePanel.Controls.Add(Me.AddTeacherBtn)
        Me.SidePanel.Controls.Add(Me.AddStudentBtn)
        Me.SidePanel.Controls.Add(Me.ImagePanel)
        Me.SidePanel.Controls.Add(Me.SideTopPanel)
        Me.SidePanel.Dock = System.Windows.Forms.DockStyle.Left
        Me.SidePanel.Location = New System.Drawing.Point(0, 0)
        Me.SidePanel.Name = "SidePanel"
        Me.SidePanel.Padding = New System.Windows.Forms.Padding(1)
        Me.SidePanel.Size = New System.Drawing.Size(229, 749)
        Me.SidePanel.TabIndex = 3
        '
        'Timer4
        '
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1081, 749)
        Me.Controls.Add(Me.MainPanel)
        Me.Controls.Add(Me.MainTopPanel)
        Me.Controls.Add(Me.SidePanel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.Name = "Form1"
        Me.Text = "ANHS Automated Attendance System"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MainPanel.ResumeLayout(False)
        Me.MainPanel.PerformLayout()
        Me.ImagePanel.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SideTopPanel.ResumeLayout(False)
        Me.SidePanel.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Timer3 As Timer
    Friend WithEvents btnAbout As Button
    Friend WithEvents btnLogs As Button
    Friend WithEvents btmTimeOut As Button
    Friend WithEvents btnAdminSettings As Button
    Friend WithEvents btnTimeIn As Button
    Friend WithEvents AddTeacherBtn As Button
    Friend WithEvents AddStudentBtn As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents MainPanel As Panel
    Friend WithEvents MainTopPanel As Panel
    Friend WithEvents ImagePanel As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents SideTopPanel As Panel
    Friend WithEvents SideBtn As Button
    Friend WithEvents Timer2 As Timer
    Friend WithEvents SidePanel As Panel
    Friend WithEvents btnLogOut As Button
    Friend WithEvents laberTimer As Label
    Friend WithEvents Timer4 As Timer
End Class
