﻿Imports System.Data.OleDb
Imports System.IO
Imports System.Data.SqlClient

Public Class student_reg
    Dim gender As String
    Dim grade As String
    Dim con As New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\ANHSDB.accdb")
    Dim cm As New OleDbCommand
    Dim bytImage() As Byte
    Dim section As String
    Dim i As Integer

    Dim imgpath As String
    Dim arrImage() As Byte
    Dim da As New OleDb.OleDbDataAdapter
    Private Sub student_reg_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Timer1.Start()
        Timer2.Start()
    End Sub



    'LOADIMAGE
    Sub LOADS()
        Dim sqlp As String = "select * from studentDb where Rfid_Tag= '" & txtRfid.Text & "'"
        con.Open()
        With cmd
            .Connection = con
            .CommandText = sqlp

        End With
        Dim publictable As New DataTable
        Try
            da.SelectCommand = cmd
            da.Fill(publictable)
            arrImage = publictable.Rows(0).Item(9)
            Dim mstream As New System.IO.MemoryStream(arrImage)
            Pic1.Image = Image.FromStream(mstream)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try

    End Sub



    'Load Recoeds from database
    Sub LoadRecords()
        Try
            Dim sql As String
            Dim cmd As New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter
            con.Open()
            sql = "select * from studentDb "
            cmd.Connection = con
            cmd.CommandText = sql
            da.SelectCommand = cmd

            da.Fill(dt)

            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            con.Close()
        End Try


    End Sub

    'Clear the textbox
    Sub Clear()
        txtRfid.Clear()
        txtFname.Clear()
        txtMname.Clear()
        txtLname.Clear()
        txtAge.Clear()
        txtSchool_id.Clear()
        Pic1.Image = Nothing 
        txtRfid.Focus()
        GradeComboBox.Text = ""
        SectionComboBox.Text = ""
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles txtSchool_id.TextChanged

    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        gender = "Male"
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        gender = "Female"
    End Sub




    Private Sub saveImage(sql As String)
        Try

            Dim arrImage() As Byte
            Dim mstream As New System.IO.MemoryStream()

            'SPECIFIES THE FILE FORMAT OF THE IMAGE
            Pic1.Image.Save(mstream, System.Drawing.Imaging.ImageFormat.Jpeg)

            'RETURNS THE ARRAY OF UNSIGNED BYTES FROM WHICH THIS STREAM WAS CREATED
            arrImage = mstream.GetBuffer()

            'GET THE SIZE OF THE STREAM IN BYTES
            Dim FileSize As UInt32
            FileSize = mstream.Length
            'CLOSES THE CURRENT STREAM AND RELEASE ANY RESOURCES ASSOCIATED WITH THE CURRENT STREAM
            mstream.Close()

            con.Open()

            cmd = New OleDbCommand
            With cmd
                .Connection = con
                .CommandText = sql
                .Parameters.AddWithValue("@Picture", arrImage)
                .ExecuteNonQuery()
            End With
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            con.Close()
        End Try
    End Sub


    'Save Buttons
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            If MsgBox("Are you sure you want to save this record?", vbYesNo + vbQuestion) = vbYes Then
                con.Open()

                Dim sql As String = "INSERT INTO studentDb (RFID_Tag, School_ID, First_Name, Middle_Name, Last_Name, Age, Gender,sections, Grade ) values ('" & txtRfid.Text & "', '" & txtSchool_id.Text & "', '" & txtFname.Text & "', '" & txtMname.Text & "', '" & txtLname.Text & "', '" & txtAge.Text & "', '" & gender & "', '" & section & "', '" & grade & "')"
                cmd = New OleDb.OleDbCommand(sql, con)
                With cmd
                    .Parameters.AddWithValue("@RFID_Tag", txtRfid.Text)
                    .Parameters.AddWithValue("@First_Name", txtFname.Text)
                    .Parameters.AddWithValue("@Middle_Name", txtMname.Text)
                    .Parameters.AddWithValue("@Last_Name", txtLname.Text)
                    .Parameters.AddWithValue("@Age", txtAge.Text)

                    .ExecuteNonQuery()
                End With

                con.Close()

                'Insert Image
                sql = "UPDATE  studentDb SET Picture= @Picture WHERE Rfid_Tag ='" & txtRfid.Text & "'"
                saveImage(sql)

                MsgBox("Record has been Successfully saved.", vbInformation)
                Clear()
                LoadRecords()

            End If
        Catch ex As Exception
            con.Close()
            MsgBox(ex.Message, vbCritical)
        End Try

    End Sub

    Private Sub btnLoad_Click(sender As Object, e As EventArgs) Handles btnLoad.Click
        LoadRecords()
    End Sub


    'Grade ComboBox
    Private Sub GradeComboBox_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GradeComboBox.SelectedIndexChanged
        If GradeComboBox.Text = "12" Then
            grade = "12"
        ElseIf GradeComboBox.Text = "11" Then
            grade = "11"
        ElseIf GradeComboBox.Text = "10" Then
            grade = "10"
        ElseIf GradeComboBox.Text = "9" Then
            grade = "9"
        ElseIf GradeComboBox.Text = "8" Then
            grade = "8"
        ElseIf GradeComboBox.Text = "7" Then
            grade = "7"

        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        LoadRecords()
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Timer1.Stop()
    End Sub


    'Check the RFID tag if its already exist
    Private Sub txtRfid_TextChanged(sender As Object, e As EventArgs) Handles txtRfid.TextChanged

        Try
            If txtRfid.Text.Length >= 10 Then
                con.Open()
                cmd = New OleDb.OleDbCommand("select * from studentDb where RFID_Tag like '" & txtRfid.Text & "'", con)
                dr = cmd.ExecuteReader

                While dr.Read
                    txtFname.Text = dr.Item("First_Name").ToString
                    txtMname.Text = dr.Item("Middle_Name").ToString
                    txtLname.Text = dr.Item("Last_Name").ToString
                    txtAge.Text = dr.Item("Age").ToString
                    txtSchool_id.Text = dr.Item("School_ID").ToString
                    GradeComboBox.Text = dr.Item("Grade").ToString
                    SectionComboBox.Text = dr.Item("sections").ToString

                End While
                dr.Close()
                con.Close()
                LOADS()
                txtRfid.SelectionStart = 0
                txtRfid.SelectionLength = Len(txtRfid.Text)
                txtRfid.Focus()


            Else

                txtFname.Clear()
                txtMname.Clear()
                txtLname.Clear()
                txtAge.Clear()
                txtSchool_id.Clear()
                Pic1.Image = Nothing

            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try



    End Sub


    'Browse Piture button
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try

            Dim OFD As FileDialog = New OpenFileDialog()

            OFD.Filter = "Image File (*.jpg;*.bmp;*.gif)|*.jpg;*.bmp;*.gif"

            If OFD.ShowDialog() = DialogResult.OK Then
                imgpath = OFD.FileName
                Pic1.ImageLocation = imgpath

            End If

            OFD = Nothing

        Catch ex As Exception
            MsgBox(ex.Message.ToString())
        End Try
    End Sub


    'section ComboBox
    Private Sub SectionComboBox_SelectedIndexChanged(sender As Object, e As EventArgs) Handles SectionComboBox.SelectedIndexChanged
        If SectionComboBox.Text = "ICT" Then
            section = "ICT"
        ElseIf SectionComboBox.Text = "Smaw" Then
            section = "Smaw"
        ElseIf SectionComboBox.Text = "Humss" Then
            section = "Humss"
        ElseIf SectionComboBox.Text = "ABM" Then
            section = "ABM"
        ElseIf SectionComboBox.Text = "Steam" Then
            section = "Steam"
        ElseIf SectionComboBox.Text = "Rizal" Then
            section = "Rizal"
        ElseIf SectionComboBox.Text = "Santos" Then
            section = "Santos"
        ElseIf SectionComboBox.Text = "Zara" Then
            section = "Zara"
        ElseIf SectionComboBox.Text = "Escuro" Then
            section = "Escuro"
        ElseIf SectionComboBox.Text = "San Juan" Then
            section = "San Juan"
        ElseIf SectionComboBox.Text = "Almeda" Then
            section = "Almeda"
        ElseIf SectionComboBox.Text = "Campus" Then
            section = "Campus"
        ElseIf SectionComboBox.Text = "Aguilar" Then
            section = "Aguilar"
        ElseIf SectionComboBox.Text = "Virchow" Then
            section = "Virchow"
        ElseIf SectionComboBox.Text = "Mendel" Then
            section = "Mendel"
        ElseIf SectionComboBox.Text = "Watson" Then
            section = "Watson"
        ElseIf SectionComboBox.Text = "Pastuer" Then
            section = "Pasteur"
        ElseIf SectionComboBox.Text = "Crick" Then
            section = "Crick"
        ElseIf SectionComboBox.Text = "Darwin" Then
            section = "Darwin"
        ElseIf SectionComboBox.Text = "Avogadro" Then
            section = "Avogadro"
        ElseIf SectionComboBox.Text = "Boyle" Then
            section = "Boyle"
        ElseIf SectionComboBox.Text = "Charles" Then
            section = "Charles"
        ElseIf SectionComboBox.Text = "Dalton" Then
            section = "Dalton"
        ElseIf SectionComboBox.Text = "Mendeleev" Then
            section = "Mendeleev"
        ElseIf SectionComboBox.Text = "Paraday" Then
            section = "Paraday"
        ElseIf SectionComboBox.Text = "Newton" Then
            section = "Newton"
        ElseIf SectionComboBox.Text = "Galileo" Then
            section = "Galileo"
        ElseIf SectionComboBox.Text = "Einstein" Then
            section = "Einstein"
        ElseIf SectionComboBox.Text = "Aristotle" Then
            section = "Aristotle"
        ElseIf SectionComboBox.Text = "Edison" Then
            section = "Edison"
        End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        con.Close()
        con.Open()
        Dim cmd3 As New OleDbCommand("Delete from studentDb where Rfid_Tag = @Rfid_Tag", con)
        cmd3.Parameters.AddWithValue("@Rfid_Tag", txtRfid.Text)
        cmd3.ExecuteNonQuery()
        con.Close()
        MsgBox("Record deleted successfully!", vbOKOnly, vbCritical)
        Clear()
        LoadRecords()
    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        Clear()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Try

            If txtRfid.Text >= 10 Then
                con.Open()
                Dim sql As String = "UPDATE studentDb SET School_ID = '" & txtSchool_id.Text & "', First_Name= '" & txtFname.Text & "', Middle_Name= '" & txtMname.Text & "', Last_Name= '" & txtLname.Text & "', Age= '" & txtAge.Text & "', Gender='" & gender & "',sections='" & section & "', Grade='" & grade & "' WHERE Rfid_Tag = '" & txtRfid.Text & "'"
                cmd = New OleDb.OleDbCommand(sql, con)
                cmd.ExecuteNonQuery()
                con.Close()
                'Insert Image
                sql = "UPDATE  studentDb SET Picture= @Picture WHERE Rfid_Tag ='" & txtRfid.Text & "'"
                saveImage(sql)
                'MsgBox("Successfully Updated!")
                Clear()
            Else
                MessageBox.Show("Fail to update record!", "FAILD!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Clear()
                LoadRecords()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
End Class