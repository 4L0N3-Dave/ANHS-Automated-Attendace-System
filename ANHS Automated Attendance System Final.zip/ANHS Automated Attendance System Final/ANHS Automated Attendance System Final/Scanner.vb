﻿Public Class Scanner

    Dim con As New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\ANHSDB.accdb")
    Public cm As New OleDb.OleDbCommand
    Public dr As OleDb.OleDbDataReader
    Public result As String
    Dim araw As String
    Dim arrImage() As Byte

    'Student LOADIMAGE 
    Sub LOADS()
        Dim sqlp As String = "select * from studentDb where Rfid_Tag= '" & txtrfid.Text & "'"
        con.Open()
        With cmd
            .Connection = con
            .CommandText = sqlp

        End With
        Dim publictable As New DataTable
        Try
            da.SelectCommand = cmd
            da.Fill(publictable)
            arrImage = publictable.Rows(0).Item(9)
            Dim mstream As New System.IO.MemoryStream(arrImage)
            Pic1.Image = Image.FromStream(mstream)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try

    End Sub


    'TeacherLOADIMAGE
    Sub LOADS1()
        Dim sqlp As String = "select * from teacherDb where Rfid_Tag= '" & txtrfid.Text & "'"
        con.Open()
        With cmd
            .Connection = con
            .CommandText = sqlp

        End With
        Dim publictable As New DataTable
        Try
            da.SelectCommand = cmd
            da.Fill(publictable)
            arrImage = publictable.Rows(0).Item(7)
            Dim mstream As New System.IO.MemoryStream(arrImage)
            Pic1.Image = Image.FromStream(mstream)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub

    Private Sub txtrfid_TextChanged(sender As Object, e As EventArgs) Handles txtrfid.TextChanged

        'Check Student
        Try
            If txtrfid.Text.Length >= 10 Then
                con.Open()
                cmd = New OleDb.OleDbCommand("select * from studentDb where RFID_Tag like '" & txtrfid.Text & "'", con)
                dr = cmd.ExecuteReader

                While dr.Read
                    txtFname.Text = dr.Item("First_Name").ToString
                    txtMname.Text = dr.Item("Middle_Name").ToString
                    txtLname.Text = dr.Item("Last_Name").ToString
                    txtGrade.Text = dr.Item("Grade").ToString
                    txtSection.Text = dr.Item("sections").ToString
                    txtSchool_id.Text = dr.Item("School_ID").ToString



                End While

                dr.Close()
                con.Close()
                LOADS()
                LOADS1()
                txtrfid.SelectionStart = 0
                txtrfid.SelectionLength = Len(txtrfid.Text)
                txtrfid.Focus()


                'techer

                con.Open()
                cmd = New OleDb.OleDbCommand("select * from teacherDb where RFID_Tag like '" & txtrfid.Text & "'", con)
                dr = cmd.ExecuteReader

                While dr.Read
                    txtFname.Text = dr.Item("First_Name").ToString
                    txtMname.Text = dr.Item("Middle_Name").ToString
                    txtLname.Text = dr.Item("Last_Name").ToString
                    txtSchool_id.Text = dr.Item("School_ID").ToString


                End While
                dr.Close()
                con.Close()

                txtrfid.SelectionStart = 0
                txtrfid.SelectionLength = Len(txtrfid.Text)
                txtrfid.Focus()


                'Insert Into Logs
                Try
                    con.Open()
                    Dim sql As String = "INSERT INTO Logs (RFID_Tag, LogDate, TimeIn, AM_Status ) values ('" & txtrfid.Text & "', '" & LabelDate.Text & "', '" & TimeOfDay & "', '" & "Time In" & "')"
                    cmd = New OleDb.OleDbCommand(sql, con)
                    With cmd
                        .Parameters.AddWithValue("@RFID_Tag", txtrfid.Text)
                        .Parameters.AddWithValue("@LogDate", LabelDate.Text)
                        .ExecuteNonQuery()
                    End With
                    txtStatus.Text = "Successfully Time In"

                    con.Close()
                    Timer1.Start()
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try


            Else

                txtFname.Clear()
                txtMname.Clear()
                txtLname.Clear()
                txtGrade.Clear()
                txtSection.Clear()
                txtSchool_id.Clear()

            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Sub scan()
        Try
            If txtrfid.Text = "" Then
                MessageBox.Show("Please enter RFID Tag", "Warring", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Else
                reloadtxt("select * from studentDb where RFID_Tag like '" & txtrfid.Text & "'")
                If dt.Rows.Count > 0 Then
                    reloadtxt("select * from Logs where RFID_Tag like '" & txtrfid.Text & "' and LogDate ='" & LabelDate.Text & "' and AM_Status = 'Time In' and PM_Status='Time Out'")
                    If dt.Rows.Count > 0 Then
                        MessageBox.Show("You have already time in and time out for today", "Already", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Else
                        reloadtxt("select * from Logs where RFID_Tag like '" & txtrfid.Text & "' and LogDate ='" & LabelDate.Text & "' and AM_Status = 'Time In'")
                        If dt.Rows.Count > 0 Then
                            updateLogged("UPDATE Logs SET TimeOut='" & TimeOfDay & "', PM_Status='Time Out' WHERE Rfid_Tag='" & txtrfid.Text & "' AND LogDate='" & LabelDate.Text & "'")
                            MessageBox.Show("Successfully Time Out", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Else
                            createLogged("INSERT INTO Logs(Rfid_Tag, LogDate, TimeIn, AM_Status)VALUES('" & txtrfid.Text & "','" & LabelDate.Text & "','" & TimeOfDay & "','Time In')")
                            MessageBox.Show("Successfully Time In", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If
                    End If
                Else
                    MessageBox.Show("Student RFID not found", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub


    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        txtFname.Clear()
        txtMname.Clear()
        txtLname.Clear()
        txtGrade.Clear()
        txtSchool_id.Clear()
        txtSection.Clear()
        txtrfid.Clear()
        txtStatus.Clear()
        Pic1.Image = Nothing
    End Sub
    Public Sub createLogged(ByVal sql As String)
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        LabelDate.Text = DateTime.Now.ToString("yyy/M/dd")
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        Timer1.Stop()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Scanner_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer4.Start()
    End Sub



    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtSection.TextChanged

    End Sub


    Sub Save_Time_In()
        con.Open()
        Dim sql As String = "INSERT INTO Logs (RFID_Tag, LogDate, TimeIn, AM_Status ) values ('" & txtrfid.Text & "', '" & LabelDate.Text & "', '" & TimeOfDay & "', '" & "Time In" & "')"
        cmd = New OleDb.OleDbCommand(sql, con)
        With cmd
            .Parameters.AddWithValue("@RFID_Tag", txtrfid.Text)
            .Parameters.AddWithValue("@LogDate", LabelDate.Text)
            .ExecuteNonQuery()
        End With

        con.Close()
    End Sub

    Sub Time_In()

        con.Open()
        Dim sql As String = "select * from Logs where RFID_Tag like '" & txtrfid.Text & "' and LogDate ='" & LabelDate.Text & "' and AM_Status = '" & "Time In " & "' "
        cmd = New OleDb.OleDbCommand(sql, con)
        MsgBox("You already time In this Day", vbOK)
        con.Close()
    End Sub

    Sub Save_Time_Out()
        con.Open()
        Dim sql As String = "UPDATE Logs SET TimeOut='" & TimeOfDay & "', PM_Status='Time Out' WHERE Rfid_Tag='" & txtrfid.Text & "' AND LogDate='" & LabelDate.Text & "'"
        cmd = New OleDb.OleDbCommand(sql, con)
        con.Close()
    End Sub


    'Check if the Student already Time In/Out This day
    Sub Check()
        If txtrfid.Text >= 10 Then
            con.Open()
            Dim sql As String = "select * from Logs where RFID_Tag like '" & txtrfid.Text & "' and LogDate ='" & LabelDate.Text & "' and AM_Status = '" & "Time In " & "' and PM_Status = '" & "Time Out " & "' "
            cmd = New OleDb.OleDbCommand(sql, con)
            txtStatus.Text = "Already Time In/Out This day"
            con.Close()
        Else
            con.Open()
            Dim sql As String = "INSERT INTO Logs (RFID_Tag, LogDate, TimeIn, AM_Status ) values ('" & txtrfid.Text & "', '" & LabelDate.Text & "', '" & TimeOfDay & "', '" & "Time In" & "')"
            cmd = New OleDb.OleDbCommand(sql, con)
            With cmd
                .Parameters.AddWithValue("@RFID_Tag", txtrfid.Text)
                .Parameters.AddWithValue("@LogDate", LabelDate.Text)
                .ExecuteNonQuery()
            End With
            txtStatus.Text = "time In Successfully"
            con.Close()
            If txtrfid.Text >= 10 Then
                con.Open()
                Dim sql1 As String = "select * from Logs where RFID_Tag like '" & txtrfid.Text & "' and LogDate ='" & LabelDate.Text & "' and PM_Status = '" & "Time Out " & "' "
                cmd = New OleDb.OleDbCommand(sql1, con)
                txtStatus.Text = "Already Time Out This day"
                con.Close()
            Else
                con.Open()
                Dim sql2 As String = "UPDATE Logs SET TimeOut='" & TimeOfDay & "', PM_Status='Time Out' WHERE Rfid_Tag='" & txtrfid.Text & "' AND LogDate='" & LabelDate.Text & "'"
                cmd = New OleDb.OleDbCommand(sql2, con)
                txtStatus.Text = "Time Out Successfuly"
                con.Close()
            End If

        End If



    End Sub

    Sub reader()
        con.Open()
        cmd = New OleDb.OleDbCommand("select * from Logs where RFID_Tag like '" & txtrfid.Text & "' and LogDate ='" & LabelDate.Text & "' and AM_Status = '" & "Time In " & "' and PM_Status = '" & "Time Out " & "' ", con)
        dr = cmd.ExecuteReader
        dr.Close()
        con.Close()
    End Sub

    Sub read_am()
        con.Open()
        cmd = New OleDb.OleDbCommand("select * from Logs where RFID_Tag like '" & txtrfid.Text & "' and LogDate ='" & LabelDate.Text & "' and AM_Status = '" & "Time In " & "' ", con)
        dr = cmd.ExecuteReader
        dr.Close()
        con.Close()
    End Sub

    Private Sub labelTime_Click(sender As Object, e As EventArgs) Handles labelTime.Click

    End Sub

    Private Sub Timer4_Tick(sender As Object, e As EventArgs) Handles Timer4.Tick
        labelTime.Text = TimeOfDay.ToString("h:mm:ss tt")
    End Sub

    Private Sub LabelDate_Click(sender As Object, e As EventArgs) Handles LabelDate.Click

    End Sub
End Class