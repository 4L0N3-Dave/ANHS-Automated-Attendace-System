﻿Imports System.Data.SqlClient
Imports System.Configuration


Public Class Login
    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MessageBox.Show("Please enter required fields!", "Authentication Error!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Dim con As New System.Data.OleDb.OleDbConnection()
            con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\admin.accdb"

            Try
                Dim sql As String = "SELECT * FROM ADMINS WHERE usern = '" & TextBox1.Text & "' AND passw = '" & TextBox2.Text & "' "
                Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)

                sqlCom.Connection = con
                con.Open()

                Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()
                If sqlRead.Read() Then
                    Form1.Show()
                    Me.Hide()
                    TextBox1.Text = ""
                    TextBox2.Text = ""
                    TextBox1.Focus()

                Else
                    MessageBox.Show("Username and password not match!", "Authentication Failure", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBox1.Text = ""
                    TextBox2.Text = ""
                    TextBox1.Focus()

                End If


            Catch ex As Exception
                MessageBox.Show("Failed to connect to database..", "Database connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class