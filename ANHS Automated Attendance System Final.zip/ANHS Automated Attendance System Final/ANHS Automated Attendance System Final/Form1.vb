﻿Public Class Form1

    Dim slidingMenu As String = "close"



    Sub clearTextMenuList()
        AddStudentBtn.Text = ""
        AddTeacherBtn.Text = ""
        btnTimeIn.Text = ""
        btnAdminSettings.Text = ""
        btmTimeOut.Text = ""
        btnLogs.Text = ""
        btnAbout.Text = ""
        btnLogOut.Text = ""

    End Sub

    Sub SetTextMenuList()
        AddStudentBtn.Text = "Add New Student"
        AddTeacherBtn.Text = "Add New Teacher"
        btnTimeIn.Text = "Time In Scanner"
        btnAdminSettings.Text = "Admin Settings"
        btmTimeOut.Text = "Time Out Scanner"
        btnLogs.Text = "Logs"
        btnAbout.Text = "About"
        btnLogOut.Text = "Logout"

    End Sub


    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If SidePanel.Width = 229 Then
            Me.Timer1.Enabled = False
        Else
            Me.SidePanel.Width = SidePanel.Width + 5
        End If
    End Sub

    Private Sub SideBtn_Click(sender As Object, e As EventArgs) Handles SideBtn.Click
        Timer3.Start()
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        If SidePanel.Width = 80 Then
            Me.Timer2.Enabled = False
        Else
            Me.SidePanel.Width = SidePanel.Width - 5
        End If
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        If slidingMenu = "open" Then
            SidePanel.Width += 30
            ImagePanel.Width += 30
            ImagePanel.Height += 30
            If SidePanel.Width >= 229 Then

                ImagePanel.Visible = True

                SetTextMenuList()
                slidingMenu = "close"
                Timer3.Stop()
            End If
        Else
            SidePanel.Width -= 30
            ImagePanel.Width -= 30
            ImagePanel.Height -= 30
            If SidePanel.Width <= 60 Then
                clearTextMenuList()

                ImagePanel.Visible = False

                slidingMenu = "open"
                Timer3.Stop()
            End If
        End If
    End Sub

    Private Sub AddStudentBtn_Click(sender As Object, e As EventArgs) Handles AddStudentBtn.Click
        MainPanel.Controls.Clear()
        student_reg.TopLevel = False
        MainPanel.Controls.Add(student_reg)
        student_reg.Show()
    End Sub

    Private Sub ScannerBtn_Click(sender As Object, e As EventArgs) Handles btnTimeIn.Click
        MainPanel.Controls.Clear()
        Scanner.TopLevel = False
        MainPanel.Controls.Add(Scanner)
        Scanner.Show()


    End Sub

    Private Sub TimeLogBtn_Click(sender As Object, e As EventArgs) Handles btnAdminSettings.Click
        MainPanel.Controls.Clear()
        adminSettings.TopLevel = False
        MainPanel.Controls.Add(adminSettings)
        adminSettings.Show()
    End Sub

    Private Sub AddTeacherBtn_Click(sender As Object, e As EventArgs) Handles AddTeacherBtn.Click
        MainPanel.Controls.Clear()
        add_teacher.TopLevel = False
        MainPanel.Controls.Add(add_teacher)
        add_teacher.Show()
    End Sub

    Private Sub LogoutBtn_Click(sender As Object, e As EventArgs) Handles btnAbout.Click
        MessageBox.Show("ANHS Automated Attendance System By:Grade 12-ICT Batch 2020-2021.", "Credit", MessageBoxButtons.OKCancel, MessageBoxIcon.Information)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click
        Me.Close()
        Login.Show()
    End Sub

    Private Sub Timer4_Tick(sender As Object, e As EventArgs) Handles Timer4.Tick
        laberTimer.Text = TimeOfDay.ToString("h:mm:ss tt")
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer4.Start()
    End Sub

    Private Sub MainPanel_Paint(sender As Object, e As PaintEventArgs) Handles MainPanel.Paint

    End Sub

    Private Sub AboutBtn_Click(sender As Object, e As EventArgs) Handles btnLogs.Click
        MainPanel.Controls.Clear()
        Logs.TopLevel = False
        MainPanel.Controls.Add(Logs)
        Logs.Show()
    End Sub

    Private Sub AdminSettingBtn_Click(sender As Object, e As EventArgs) Handles btmTimeOut.Click
        MainPanel.Controls.Clear()
        timeOut.TopLevel = False
        MainPanel.Controls.Add(timeOut)
        timeOut.Show()
    End Sub
End Class
