﻿

Public Class timeOut
    Dim con As New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\ANHSDB.accdb")
    Public cm As New OleDb.OleDbCommand
    Public dr As OleDb.OleDbDataReader
    Public result As String
    Dim arrImage() As Byte

    'Student LOADIMAGE 
    Sub LOADS()
        Dim sqlp As String = "select * from studentDb where Rfid_Tag= '" & txtrfid.Text & "'"
        con.Open()
        With cmd
            .Connection = con
            .CommandText = sqlp

        End With
        Dim publictable As New DataTable
        Try
            da.SelectCommand = cmd
            da.Fill(publictable)
            arrImage = publictable.Rows(0).Item(9)
            Dim mstream As New System.IO.MemoryStream(arrImage)
            Pic1.Image = Image.FromStream(mstream)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try

    End Sub


    'TeacherLOADIMAGE
    Sub LOADS1()
        Dim sqlp As String = "select * from teacherDb where Rfid_Tag= '" & txtrfid.Text & "'"
        con.Open()
        With cmd
            .Connection = con
            .CommandText = sqlp

        End With
        Dim publictable As New DataTable
        Try
            da.SelectCommand = cmd
            da.Fill(publictable)
            arrImage = publictable.Rows(0).Item(7)
            Dim mstream As New System.IO.MemoryStream(arrImage)
            Pic1.Image = Image.FromStream(mstream)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub


    Private Sub txtrfid_TextChanged(sender As Object, e As EventArgs) Handles txtrfid.TextChanged
        Try
            If txtrfid.Text.Length >= 10 Then
                con.Open()
                cmd = New OleDb.OleDbCommand("select * from studentDb where RFID_Tag like '" & txtrfid.Text & "'", con)
                dr = cmd.ExecuteReader

                While dr.Read
                    txtFname.Text = dr.Item("First_Name").ToString
                    txtMname.Text = dr.Item("Middle_Name").ToString
                    txtLname.Text = dr.Item("Last_Name").ToString
                    txtGrade.Text = dr.Item("Grade").ToString
                    txtSection.Text = dr.Item("sections").ToString
                    txtSchool_id.Text = dr.Item("School_ID").ToString



                End While

                dr.Close()
                con.Close()
                LOADS()
                LOADS1()
                txtrfid.SelectionStart = 0
                txtrfid.SelectionLength = Len(txtrfid.Text)
                txtrfid.Focus()

                con.Open()
                cmd = New OleDb.OleDbCommand("select * from teacherDb where RFID_Tag like '" & txtrfid.Text & "'", con)
                dr = cmd.ExecuteReader

                While dr.Read
                    txtFname.Text = dr.Item("First_Name").ToString
                    txtMname.Text = dr.Item("Middle_Name").ToString
                    txtLname.Text = dr.Item("Last_Name").ToString
                    txtSchool_id.Text = dr.Item("School_ID").ToString


                End While
                dr.Close()
                con.Close()

                txtrfid.SelectionStart = 0
                txtrfid.SelectionLength = Len(txtrfid.Text)
                txtrfid.Focus()



                Try
                    Save_Time_Out()
                    txtStatus.Text = "Successfully Time Out!"
                    Timer1.Start()
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try


            Else

                txtFname.Clear()
                txtMname.Clear()
                txtLname.Clear()
                txtGrade.Clear()
                txtSection.Clear()
                txtSchool_id.Clear()
                Pic1.Image = Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        txtFname.Clear()
        txtMname.Clear()
        txtLname.Clear()
        txtGrade.Clear()
        txtSchool_id.Clear()
        txtSection.Clear()
        txtrfid.Clear()
        txtStatus.Clear()
        Pic1.Image = Nothing

    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        LabelDate.Text = DateTime.Now.ToString("yyy/M/dd")
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        labelTime.Text = TimeOfDay.ToString("h:mm:ss tt")
    End Sub

    Private Sub timeOut_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer2.Start()
        Timer3.Start()
    End Sub

    Sub Save_Time_Out()
        con.Open()
        Dim sql As String = "UPDATE Logs SET TimeOut='" & TimeOfDay & "', PM_Status='Time Out' WHERE Rfid_Tag='" & txtrfid.Text & "' AND LogDate='" & LabelDate.Text & "'"
        cmd = New OleDb.OleDbCommand(sql, con)
        cmd.ExecuteNonQuery()
        con.Close()
    End Sub

End Class