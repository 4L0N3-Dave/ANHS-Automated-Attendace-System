﻿Public Class add_teacher
    Dim gender As String
    Dim teacher As String
    Dim imgpath As String
    Dim section As String
    Dim con As New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\ANHSDB.accdb")
    Dim arrImage() As Byte
    Private Sub add_teacher_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
        Timer2.Start()
    End Sub



    'TeacherLOADIMAGE
    Sub LOADS1()
        Dim sqlp As String = "select * from teacherDb where Rfid_Tag= '" & txtRfid.Text & "'"
        con.Open()
        With cmd
            .Connection = con
            .CommandText = sqlp

        End With
        Dim publictable As New DataTable
        Try
            da.SelectCommand = cmd
            da.Fill(publictable)
            arrImage = publictable.Rows(0).Item(7)
            Dim mstream As New System.IO.MemoryStream(arrImage)
            Pic1.Image = Image.FromStream(mstream)
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            da.Dispose()
            con.Close()
        End Try
    End Sub


    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub

    Private Sub saveImage(sql As String)
        Try

            Dim arrImage() As Byte
            Dim mstream As New System.IO.MemoryStream()

            'SPECIFIES THE FILE FORMAT OF THE IMAGE
            Pic1.Image.Save(mstream, System.Drawing.Imaging.ImageFormat.Jpeg)

            'RETURNS THE ARRAY OF UNSIGNED BYTES FROM WHICH THIS STREAM WAS CREATED
            arrImage = mstream.GetBuffer()

            'GET THE SIZE OF THE STREAM IN BYTES
            Dim FileSize As UInt32
            FileSize = mstream.Length
            'CLOSES THE CURRENT STREAM AND RELEASE ANY RESOURCES ASSOCIATED WITH THE CURRENT STREAM
            mstream.Close()

            con.Open()

            cmd = New OleDb.OleDbCommand
            With cmd
                .Connection = con
                .CommandText = sql
                .Parameters.AddWithValue("@Picture", arrImage)
                .ExecuteNonQuery()
            End With
        Catch ex As Exception
            MsgBox("Please Insert Image", vbOKOnly, vbCritical)
            MsgBox(ex.Message)
        Finally
            con.Close()
        End Try
    End Sub


    Sub LoadRecords()
        Try
            Dim sql As String
            Dim cmd As New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter
            con.Open()
            sql = "select * from teacherDb "
            cmd.Connection = con
            cmd.CommandText = sql
            da.SelectCommand = cmd

            da.Fill(dt)

            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            con.Close()
        End Try
    End Sub

    Sub Clear()
        txtRfid.Clear()
        txtFname.Clear()
        txtMname.Clear()
        txtLname.Clear()
        txtSchool_id.Clear()
        txtRfid.Focus()
        Pic1.Image = Nothing
        GradeComboBox.Text = ""

    End Sub


    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            If MsgBox("Are you sure you want to save this record?", vbYesNo + vbQuestion) = vbYes Then
                con.Open()

                Dim sql As String = "INSERT INTO teacherDb (Rfid_Tag, School_ID, First_Name, Middle_Name, Last_Name, Gender, Teacher) values ('" & txtRfid.Text & "', '" & txtSchool_id.Text & "', '" & txtFname.Text & "', '" & txtMname.Text & "', '" & txtLname.Text & "', '" & gender & "', '" & teacher & "')"
                cmd = New OleDb.OleDbCommand(sql, con)
                With cmd
                    .Parameters.AddWithValue("@Rfid_Tag", txtRfid.Text)
                    .Parameters.AddWithValue("@School_ID", txtSchool_id.Text)
                    .Parameters.AddWithValue("@First_Name", txtFname.Text)
                    .Parameters.AddWithValue("@Middle_Name", txtMname.Text)
                    .Parameters.AddWithValue("@Last_Name", txtLname.Text)
                    .ExecuteNonQuery()
                End With

                con.Close()
                'Insert Image
                sql = "UPDATE  teacherDb SET Picture= @Picture WHERE Rfid_Tag ='" & txtRfid.Text & "'"
                saveImage(sql)

                MsgBox("Record has been Successfully saved.", vbInformation)
                Clear()
                LoadRecords()

            End If
        Catch ex As Exception
            con.Close()
            MsgBox(ex.Message, vbCritical)
        End Try
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        gender = "Male"
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        gender = "Female"
    End Sub

    Private Sub GradeComboBox_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GradeComboBox.SelectedIndexChanged
        If GradeComboBox.Text = "Senior" Then
            teacher = "Senior"
        ElseIf GradeComboBox.Text = "Junior" Then
            teacher = "Junior"
        Else
            MsgBox("Please Select Properly ", vbInformation)


        End If
    End Sub


    Private Sub btnLoad_Click(sender As Object, e As EventArgs) Handles btnLoad.Click
        LoadRecords()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        LoadRecords()
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Timer1.Stop()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()

    End Sub

    Private Sub txtRfid_TextChanged(sender As Object, e As EventArgs) Handles txtRfid.TextChanged
        Try
            If txtRfid.Text.Length >= 10 Then
                con.Open()
                cmd = New OleDb.OleDbCommand("select * from teacherDb where RFID_Tag like '" & txtRfid.Text & "'", con)
                dr = cmd.ExecuteReader

                While dr.Read
                    txtFname.Text = dr.Item("First_Name").ToString
                    txtMname.Text = dr.Item("Middle_Name").ToString
                    txtLname.Text = dr.Item("Last_Name").ToString
                    txtSchool_id.Text = dr.Item("School_ID").ToString
                    GradeComboBox.Text = dr.Item("Teacher").ToString

                End While
                dr.Close()
                con.Close()
                LOADS1()
                txtRfid.SelectionStart = 0
                txtRfid.SelectionLength = Len(txtRfid.Text)
                txtRfid.Focus()


            Else

                txtFname.Clear()
                txtMname.Clear()
                txtLname.Clear()
                txtSchool_id.Clear()
                GradeComboBox.Text = ""
                Pic1.Image = Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try

            Dim OFD As FileDialog = New OpenFileDialog()

            OFD.Filter = "Image File (*.jpg;*.bmp;*.gif)|*.jpg;*.bmp;*.gif"

            If OFD.ShowDialog() = DialogResult.OK Then
                imgpath = OFD.FileName
                Pic1.ImageLocation = imgpath

            End If

            OFD = Nothing

        Catch ex As Exception
            MsgBox(ex.Message.ToString())
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        con.Close()
        con.Open()
        Dim cmd3 As New OleDb.OleDbCommand("Delete from teacherDb where Rfid_Tag = @Rfid_Tag", con)
        cmd3.Parameters.AddWithValue("@Rfid_Tag", txtRfid.Text)
        cmd3.ExecuteNonQuery()
        con.Close()
        MsgBox("Record deleted successfully!", vbOKOnly, vbCritical)
        Clear()
        LoadRecords()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Clear()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Try

            If txtRfid.Text >= 10 Then
                con.Open()
                Dim sql As String = "UPDATE teacherDb SET School_ID = '" & txtSchool_id.Text & "', First_Name= '" & txtFname.Text & "', Middle_Name= '" & txtMname.Text & "', Last_Name= '" & txtLname.Text & "', Gender='" & gender & "', Teacher='" & teacher & "' WHERE Rfid_Tag = '" & txtRfid.Text & "'"
                cmd = New OleDb.OleDbCommand(sql, con)
                cmd.ExecuteNonQuery()
                con.Close()
                'Insert Image
                sql = "UPDATE  teacherDb SET Picture= @Picture WHERE Rfid_Tag ='" & txtRfid.Text & "'"
                saveImage(sql)
                MsgBox("Successfully Updated!")
                Clear()
                LoadRecords()
            Else
                MessageBox.Show("Fail to update record!", "FAILD!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Clear()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class