﻿Public Class Logs
    Dim con As New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\ANHSDB.accdb")
    Private Sub Logs_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
        Timer2.Start()
    End Sub

    Sub reload()
        Try
            Dim sql As String
            Dim cmd As New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter
            con.Open()
            sql = "select * from Logs "
            cmd.Connection = con
            cmd.CommandText = sql
            da.SelectCommand = cmd

            da.Fill(dt)

            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        reload()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        reload()
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Timer1.Stop()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If txtrfid.Text = "" And txtdate.Text = "" Then
            MessageBox.Show("Please enter student RFID tag and Date!", "Student not Found!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            con.Open()
            cmd = New OleDb.OleDbCommand("select * from Logs where Rfid_Tag='" & txtrfid.Text & "' and LogDate = '" & txtdate.Text & "'", con)
            dr = cmd.ExecuteReader()

            While dr.Read
                txtStatus1.Text = dr.Item("AM_Status").ToString
                txtTime1.Text = dr.Item("TimeIn").ToString
                txtStatus2.Text = dr.Item("PM_Status").ToString
                txtTime2.Text = dr.Item("TimeOut").ToString
            End While
            dr.Close()
            con.Close()
        End If


        Try
            If txtrfid.Text.Length >= 10 Then
                con.Open()
                cmd = New OleDb.OleDbCommand("select * from studentDb where RFID_Tag like '" & txtrfid.Text & "'", con)
                dr = cmd.ExecuteReader

                While dr.Read
                    txtFname.Text = dr.Item("First_Name").ToString
                    txtMname.Text = dr.Item("Middle_Name").ToString
                    txtLname.Text = dr.Item("Last_Name").ToString
                    txtAge.Text = dr.Item("Age").ToString
                    txtGrade.Text = dr.Item("Grade").ToString
                    txtsection.Text = dr.Item("sections").ToString


                End While
                dr.Close()
                con.Close()

                txtrfid.SelectionStart = 0
                txtrfid.SelectionLength = Len(txtrfid.Text)
                txtrfid.Focus()

                'techer

                con.Open()
                cmd = New OleDb.OleDbCommand("select * from teacherDb where RFID_Tag like '" & txtrfid.Text & "'", con)
                dr = cmd.ExecuteReader

                While dr.Read
                    txtFname.Text = dr.Item("First_Name").ToString
                    txtMname.Text = dr.Item("Middle_Name").ToString
                    txtLname.Text = dr.Item("Last_Name").ToString
                    txtLvl.Text = dr.Item("Teacher").ToString


                End While
                dr.Close()
                con.Close()

                txtrfid.SelectionStart = 0
                txtrfid.SelectionLength = Len(txtrfid.Text)
                txtrfid.Focus()



            Else

                txtFname.Clear()
                txtMname.Clear()
                txtLname.Clear()
                txtAge.Clear()
                txtGrade.Clear()
                txtsection.Clear()

            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        txtrfid.Text = "RFID_TAG"
        txtdate.Text = "yyyy/mm/dd"
        txtsection.Text = ""
        txtGrade.Text = ""
        txtTime1.Text = ""
        txtTime2.Text = ""
        txtStatus1.Text = ""
        txtStatus2.Text = ""
        txtFname.Text = ""
        txtMname.Text = ""
        txtLname.Text = ""
        txtAge.Text = ""
    End Sub
End Class