﻿Module CRUDConnection
    Dim con As New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\ANHSDB.accdb")
    Public cmd As New OleDb.OleDbCommand
    Public dr As OleDb.OleDbDataReader
    Public da As New OleDb.OleDbDataAdapter
    Public dt As New DataTable
    Public ds As New DataSet
    Dim result As String


    Public Sub create(ByVal sql As String)
        Try
            con.Open()
            With cmd
                .Connection = con
                .CommandText = sql

                result = cmd.ExecuteNonQuery

                If result = 0 Then
                    MessageBox.Show("Data failed to insert ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Else
                    MessageBox.Show("Data have been successfully inserted", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If

            End With
        Catch ex As Exception
        Finally
            con.Close()

        End Try
    End Sub

    Public Sub reload(ByVal sql As String, ByVal DTG As Object)

        Try
            con.Open()
            dt = New DataTable
            With cmd
                .Connection = con
                .CommandText = sql
            End With
            da.SelectCommand = cmd
            da.Fill(dt)
            DTG.DataSourse = dt
        Catch ex As Exception
        Finally
            con.Close()
            da.Dispose()
        End Try

    End Sub

    Public Sub reloadtxt(ByVal sql As String)
        Try
            con.Open()
            With cmd
                .Connection = con
                .CommandText = sql
            End With

            dt = New DataTable
            da = New OleDb.OleDbDataAdapter(sql, con)
            da.Fill(dt)
        Catch ex As Exception
        Finally
            con.Close()
            da.Dispose()
        End Try
    End Sub

    Public Sub createLog(ByVal sql As String)
        Try
            con.Open()
            With cmd
                .Connection = con
                .CommandText = sql
                result = cmd.ExecuteNonQuery
            End With
        Catch ex As Exception
        Finally
            con.Close()
        End Try
    End Sub
    Public Sub updateLogged(ByVal sql As String)
        Try
            con.Open()
            With cmd
                .Connection = con
                .CommandText = sql
                result = cmd.ExecuteNonQuery
            End With
        Catch ex As Exception
        Finally
            con.Close()
        End Try
    End Sub



End Module
